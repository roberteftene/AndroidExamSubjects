package com.app.bugetpersonal;

import androidx.fragment.app.Fragment;

public class FragmentGrafic extends Fragment {

}
